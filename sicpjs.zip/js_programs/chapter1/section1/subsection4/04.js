function square(x) {
    return x * x;
}
square(2 + 5);
