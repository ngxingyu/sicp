function f(g) {
   return g(2);
}
f(z => z * (z + 1));
