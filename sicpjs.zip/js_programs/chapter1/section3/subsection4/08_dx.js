const dx = 0.00001;
