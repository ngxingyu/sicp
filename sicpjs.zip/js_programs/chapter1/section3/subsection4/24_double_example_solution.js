function inc(n) {
    return n + 1;
}
double(double(double))(inc)(5); // returns 21
