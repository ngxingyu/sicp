// cont_frac to be written by student; see exercise 1.37
cont_frac(i => 1, i => 1, 20);
