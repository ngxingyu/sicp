const xs = list("apple", "banana", "cranberry");
an_element_of(xs);	
// Press "Run" for the first solution. Type
// retry
// in the REPL on the right, for more solutions
