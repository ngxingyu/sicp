first_answer('can_do_job(x, pair("computer", y))');
