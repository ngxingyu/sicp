first_answer('and(salary($person, $amount), javascript_value($amount > 50000))');
