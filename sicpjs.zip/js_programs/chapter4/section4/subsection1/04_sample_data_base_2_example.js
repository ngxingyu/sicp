first_answer('supervisor(x, list("Bitdiddle", "Ben"))');
