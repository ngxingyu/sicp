first_answer('and(job($person, list("computer", "programmer")), address($person, $where))');
