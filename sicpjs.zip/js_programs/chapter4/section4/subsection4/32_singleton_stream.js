function singleton_stream(x) {
    return pair(x, () => null);
}

parse_query_verbose('assert(                           \
rule(append_to_form(null, y, y)))                ', "verbose");
parse_query_verbose('assert(                           \
rule(append_to_form(pair(u, v), y, pair(u, z)),  \
     append_to_form(v, y, z)))                   ', "verbose");

first_answer('append_to_form(x, y, list("a", "b", "c", "d"))');
// parse_query_verbose('append_to_form(x, y, list("a", "b", "c", "d"))', "");
