list($x, $x)
