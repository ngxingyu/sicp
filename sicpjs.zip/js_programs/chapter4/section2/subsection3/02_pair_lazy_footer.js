head(tail(pair(1, pair(3, 2))));
`;
