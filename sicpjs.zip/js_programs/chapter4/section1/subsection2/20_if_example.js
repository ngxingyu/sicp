const my_cond_expr = 
    parse("true ? 1 : 2;");
is_conditional(my_cond_expr);
conditional_predicate(my_cond_expr);
conditional_consequent(my_cond_expr);
conditional_alternative(my_cond_expr);
