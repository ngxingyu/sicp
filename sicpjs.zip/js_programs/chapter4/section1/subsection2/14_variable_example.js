const my_name_statement = parse("x;");
display(is_name(my_name_statement));
display(symbol_of_name(my_name_statement));
